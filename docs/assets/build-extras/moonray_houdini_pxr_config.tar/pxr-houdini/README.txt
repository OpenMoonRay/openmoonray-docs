You can use this cmake config to build MoonRay using the USD libraries shipped with Houdini.

In your CMake preset, remove the settings for PXR_USD_LOCATION and PXR_INCLUDE_DIR. 
Add this directory (pxr-houdini) to the CMake config directory, 
and set some environment variables to point into your Houdini install:

    "environment": {
        ...
        - remove PXR_USD_LOCATION -
        - remove PXR_INCLUDE_DIR -
        - add:
        "PREFIX_PXR"            : "<somepath>/pxr-houdini",
        "HOUDINI_INSTALL_DIR"   : "<somepath>/houdini/<ver>/ext",
        "PXR_LIB_PREFIX"        : "$env{HOUDINI_INSTALL_DIR}/dsolib",
        "PXR_INCLUDE_PREFIX"    : "$env{HOUDINI_INSTALL_DIR}/toolkit/include",
        "PXR_DEPS_PREFIX"       : "$env{DEPS_ROOT}",
        "PXR_BOOST_PYTHON_LIB"  : "$env{HOUDINI_INSTALL_DIR}/dsolib/libhboost_python39-mt-x64.so",
        ...
    },
     "cacheVariables": {
                "CMAKE_PREFIX_PATH": "$env{DEPS_ROOT};$env{PREFIX_PXR}"
    }

(replacing <somepath> with the actual location of these files)

Then run the MoonRay CMake build as usual. CMake should pick up the version of USD shipped with Houdini
